package DAO;

/**
 *
 * @author Carol
 */
import Conexao.Conexao;
import Obj_pacientes2.Obj_pacientes2;
import java.util.ArrayList;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class DAO_pacientes2 {
    
    Conexao con;
    
    ArrayList<Obj_pacientes2> lista;
    Obj_pacientes2            linha;
    
 public boolean exclui_Genero (int Codigo) throws Exception{
     boolean saida = false;
     this.con = new Conexao();
     String SQL = "DELETE FROM Obj_paciente WHERE Projeto =?";
     PreparedStatement ps = this.con.getConexao().prepareStatement(SQL);
     ps.setInt(1, Codigo);
     if (0 <=ps.executedUpdate()){
         saida = true;
     } else {
     }
     return saida;
 }
 
 public Obj_pacientes2 Consulta_Pacientes (int codigo) throws Exception{
     this.con = new Conexao();
     String SQL = "SELECT cd_matricula, nm_nomedopaciente, dt_datadenascimento, ds_emaildopaciente, ds_graudegravidade  FROM Obj_paciente = ?";
     PreparedStatement ps = this.con.getConexao().prepareStatement(SQL);
     ps.setInt(1, codigo);
     ResultSet rs = ps.executeQuery();
    this.lista = new ArrayList();
    
    while(rs.next()){
        this.linha = new Obj_pacientes2();
        this.linha.setcd_Pacientes2(rs.getInt("cd_pacientes"));
        this.linha.setNm_Pacaientes2(rs.getString("Nm_pacientes"));
        this.linha.setDt_datadenascimento(rs.getInt("dt_datadenascimento"));
        this.linha.setDs_graudegravidade(rs.getDouble("ds_graudegravidade"));
        this.linha.setDs_emailpaciente(rs.getString("ds_emailpaciente"));
        this.linha.setDs_indicacao(rs.getString("ds_indicacao"));
    }
    return this.linha;
    
    
 }
 
    /**
     *
     * @throws Expection
     */
    public void Consulta_Pacientes () throws Expection, Exception{
    this.con = new Conexao();
    String SQL = "SELECT cd_matricula, nm_nomedopaciente, dt_datadenascimento, ds_emaildopaciente, ds_graudegravidade  FROM Obj_paciente ";
    PreparedStatement ps = this.con.getConexao().prepareStatement(SQL);
    ResultSet rs = ps.executeQuery();
    this.lista = new ArrayList();
    
    While(rs.next());
        this.linha = new Obj_pacientes2();
        this.linha.setCd_pacientes(rs.getInt("cd_pacientes"));
        this.linha.setNm_nomedopacientes(rs.getString("nm_nomedopacientes"));
        this.linha.setDt_datadenascimento(rs.getInt("dt_datadenascimento"));
        this.linha.setDs_graudegravidade(rs.getDouble("ds_graudegravidade"));
        this.linha.setDs_emailpaciente(rs.getString("ds_emailpaciente"));
        this.linha.setDs_indicacao(rs.getString("ds_indicacao"));
        
        this.lista.add(this.linha);
        }
    return lista;    


    private void While(boolean next) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private static class Expection extends Exception {

        public Expection() {
        }
    }

    private static class lista {

        public lista() {
        }
    }
}
     
