package javaapplication1;

import Obj_pacientes2.Obj_pacientes2;
import Obj_pacientes2.obj_convenios2;
import DAO.DAO_convenio2;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import javax.swing.JOptionPane;

/**
 *
 * @author Carol
 */
public class FichadeCadastro extends javax.swing.JFrame {
    
    DAO_cnvenio2 dao_convenio2 = new DAO_convenio2();
}
    Obj_pacientes2 paciente = new Obj_pacientes2 ();
    
    ArrayList<Obj_pacientes2> Listapaciente = new ArrayList ();
   
    obj_convenios2 convenios = new obj_convenios2 ();
    
    
    ArrayList<obj_convenios2> Listaconvenios = new ArrayList ();
   
    
    private  String ds_indicacao = "";
    private String mensagem = "";
    private int cd_Convenio;
    private String nm_Convenio;
    private Object ck_altamedica;
    private Object tf_grau;
   
    public FichadeCadastro() {
        initComponents();
    
        CargaComboBox ();
    }
   
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Ib_TituloCadastro = new javax.swing.JLabel();
        Ib_matricula = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tf_matricula = new javax.swing.JEditorPane();
        Ib_nomedopaciente = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tf_nomedopaciente = new javax.swing.JEditorPane();
        Ib_datadenascimento = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tf_data = new javax.swing.JEditorPane();
        Ib_email = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tf_email = new javax.swing.JEditorPane();
        Ib_convenio = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        combo_convenio = new javax.swing.JEditorPane();
        Ib_indicacao = new javax.swing.JLabel();
        ck_internacao = new javax.swing.JCheckBox();
        Ib_altamedica = new javax.swing.JCheckBox();
        Ib_graudegravidade = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        tf_graudegravidade = new javax.swing.JEditorPane();
        bt_limpar = new javax.swing.JButton();
        bt_salvar = new javax.swing.JButton();
        bt_relatorio = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Ib_TituloCadastro.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        Ib_TituloCadastro.setForeground(new java.awt.Color(0, 102, 102));
        Ib_TituloCadastro.setText("Ficha de Cadastro");

        Ib_matricula.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        Ib_matricula.setText("Matricula");

        jScrollPane1.setViewportView(tf_matricula);

        Ib_nomedopaciente.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        Ib_nomedopaciente.setText("Nome do Paciente");

        jScrollPane2.setViewportView(tf_nomedopaciente);

        Ib_datadenascimento.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        Ib_datadenascimento.setText("Data de Nascimento");

        jScrollPane3.setViewportView(tf_data);

        Ib_email.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        Ib_email.setText("E-mail");

        jScrollPane4.setViewportView(tf_email);

        Ib_convenio.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        Ib_convenio.setText("Convênio");

        jScrollPane5.setViewportView(combo_convenio);

        Ib_indicacao.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        Ib_indicacao.setText("Indicação");

        ck_internacao.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        ck_internacao.setText("Internação");

        Ib_altamedica.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        Ib_altamedica.setText("Alta Médica");

        Ib_graudegravidade.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        Ib_graudegravidade.setText("Grau de Gravidade");

        jScrollPane6.setViewportView(tf_graudegravidade);

        bt_limpar.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        bt_limpar.setText("Limpa");

        bt_salvar.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        bt_salvar.setText("Salvar");

        bt_relatorio.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        bt_relatorio.setText("Relatório");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(146, 146, 146)
                        .addComponent(Ib_TituloCadastro))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Ib_nomedopaciente)
                            .addComponent(Ib_matricula))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Ib_datadenascimento)
                            .addComponent(Ib_email)
                            .addComponent(Ib_convenio)
                            .addComponent(Ib_indicacao))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(ck_internacao)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(Ib_altamedica))
                            .addComponent(jScrollPane3)
                            .addComponent(jScrollPane4)
                            .addComponent(jScrollPane5)))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Ib_graudegravidade)
                            .addComponent(bt_limpar))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(bt_salvar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(bt_relatorio))
                            .addComponent(jScrollPane6))))
                .addContainerGap(43, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Ib_TituloCadastro)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(Ib_matricula)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(Ib_nomedopaciente)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Ib_datadenascimento)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Ib_email)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(Ib_convenio))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Ib_indicacao)
                    .addComponent(ck_internacao)
                    .addComponent(Ib_altamedica))
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(Ib_graudegravidade)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(57, 57, 57)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bt_limpar)
                    .addComponent(bt_salvar)
                    .addComponent(bt_relatorio))
                .addContainerGap(75, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void bt_limparActionPerformed(java.event.ActionEvent evt){
    
        limpar ();
    
    }
    
    private void ck_internacaoActionPerformed(java.event.ActionEvent evt) {
        ck_altamedica.setSelected (b: false);
       
    }
    private void combo_convenioActinPerformed(java.awt.event.ActionEvent evt);static {
    
}
    private void bt_salvarActionPerformed(java.awt.event.ActionEvent evt){
        if (!isCamposPreenchidos()){
          JOptionPane.showMessageDialog(null, "Todos os campos são obrigatórios", "Erro", JOptionPane.ERROR_MESSAGE);
          
      }else {
          
          try {
              
              paciente = new Obj_pacientes2 ();
              
              paciente.setCd_matricula(Integer.parseInt(tf_matricula.getText().trim()));
              paciente.setNm_nomedopaciente(tf_nomedopaciente.getText().trim());
              paciente.setDt_datadenascimento(Integer.parseInt(tf_data.getText().trim()));
              paciente.setDs_graudegravidade(Double.parseDouble(tf_graudegravidade.getText().trim()));
              paciente.setDs_emailpaciente(tf_email.getText().trim() );
              paciente.setDs_convenio(combo_convenio.getSelectedItem().toString());
        
       
        
        if(ck_altamedica.isSelected()){
            ds_indicacao = "Alta Medica";
        }else{
            ds_indicacao = "Internação";
        }
        
        paciente.setDs_indicacao(ds_indicacao);
        
        if(!mensagem.isEmpty()) {
            throw new Exception (mensagem);
        }
        
        mensagem = paciente.isDsEmailValido();
        
        if(!mensagem.isEmpty()) {
            throw new Exception (mensagem);
        }
        
        mensagem = paciente.isDsgraudegravidadeValido ();
        
        if(!mensagem.isEmpty()) {
            throw new Exception (mensagem); 
    }
        
        // chamada de relatorio
        //relatorio localRelat =new relatorio ()
       Listapacientes.add (paciente);
       JOptionPane.showMessageDialognull, "Paciente salvo com sucesso", "Mensagem", JOptionPane.INFORMATION_MESSAGE);
      
      limpar ();
          }
          catch (NumberFormatException erro) {
              JOptionPane.showMessageDialog(null, "Digite apenas numeros no código\n"+erro.toString(), "Erro", JOptionPane.ERROR_MESSAGE);
              
          }
          catch (Exception erro1) {
              JOptionPane.showMessageDialog(null, "Erro de validação\n"+erro1.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
          }
        }
      private void bt_relatorioActionPerformed(java.awt.event.ActionEvent evt) {
          Relatório localRelat = new Relatório ();
          localRelat.MontaTela(Listapaciente);
          localRelat.setVisible(true);
          
      }
        
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FichadeCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FichadeCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FichadeCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FichadeCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new FichadeCadastro().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Ib_TituloCadastro;
    private javax.swing.JCheckBox Ib_altamedica;
    private javax.swing.JLabel Ib_convenio;
    private javax.swing.JLabel Ib_datadenascimento;
    private javax.swing.JLabel Ib_email;
    private javax.swing.JLabel Ib_graudegravidade;
    private javax.swing.JLabel Ib_indicacao;
    private javax.swing.JLabel Ib_matricula;
    private javax.swing.JLabel Ib_nomedopaciente;
    private javax.swing.JButton bt_limpar;
    private javax.swing.JButton bt_relatorio;
    private javax.swing.JButton bt_salvar;
    private javax.swing.JCheckBox ck_internacao;
    private javax.swing.JEditorPane combo_convenio;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JEditorPane tf_data;
    private javax.swing.JEditorPane tf_email;
    private javax.swing.JEditorPane tf_graudegravidade;
    private javax.swing.JEditorPane tf_matricula;
    private javax.swing.JEditorPane tf_nomedopaciente;
    // End of variables declaration//GEN-END:variables

    public void limpar (){

        tf_data.setText(null);
        tf_email.setText(null);
        tf_graudegravidade.setText(null);
        tf_nomedopaciente.setText(null);
        tf_matricula.setText(null);
        
        combo_convenio.setSelectedIndex (anIndex: -1);
        ck_altamedica.setSelected(false);
        ck_internacao.setSelected(false);
        
}

public boolean isCamposPreenchidos(){
    boolean saida = false;
    
    
    if( (((((tf_matricula.getText().isEmpty() || tf_data.getText().isEmpty()) || tf_email.getText().isEmpty()) || tf_grau.getText().isEmpty()) || tf_nomedopaciente.getText().isEmpty()) || combo_convenio.getSelectedIndex() < 0) ||
            ck_altamedica.isSelected() && ck_internacao.isSelected())
        
    {
    } else {
        saida = true;
        }
    
    return saida;
    
}
public void CargaCombobox()
try {
cargaConvenio ();
} catch (Exception ex){
    JOptionPane.showMensageDialog(null, "Erro Conexão BD - Carga ComboBox.\n" + ex.getMessage()"Erro BD", JOptionPane.ERRO MENSAGE)
}

for (int i=0; i<listaConvenio.size(); i++){
    Ib_convenio.setSelectedIndex(-1);
}
}
public void cargaConvenio() {
    
listaConvenio = dao_convenio2.Consulta_Convenio();
}


    private void CargaComboBox() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void limpar() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private static class Listapacientes {

        private static void add(Obj_pacientes2 paciente) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public Listapacientes() {
        }
    }
}

