package javaapplication1;

import java.sql.PreparedStartement;
import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Carol
 */
public class Projeto {
     public static void main(String[] args) {
        
        
        Menu mymenu = new Menu ();
        mymenu.setVisible(true);
        
       
    }
    
}
