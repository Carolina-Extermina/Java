/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Obj_pacientes2;

/**
 *
 * @author Carol
 */
public class obj_convenios2 {
      private int cd_Convenio;
        private String nm_Convenio;

    public int getCd_Convenio() {
        return cd_Convenio;
    }

    public void setCd_Convenio(int cd_Convenio) {
        this.cd_Convenio = cd_Convenio;
    }

    public String getNm_Convenio() {
        return nm_Convenio;
    }

    public void setNm_Convenio(String nm_Convenio) {
        this.nm_Convenio = nm_Convenio;
    }
    
    
}
